import setuptools

setuptools.setup(name='pytest-configloader',
                 version='0.1',
                 description='py.test plugin to read config param from command line',
                 #long_description=open('README').read().strip(),
                 author='Yong.Reny',
                 author_email='Yong.Reny@alibaba-inc.com',
                 url='http://svn.alisoft-inc.com/repos/alisoft_QA/Code/alitest/pytest_plugin/configloader',
                 py_modules=['pytest_configloader'],
                 install_requires=['py>=1.1.1'],
                 entry_points={'pytest11': ['pytest-configloader = pytest_configloader']},
                 license='Commercial',
                 zip_safe=False,
                 keywords='py.test pytest'
                 )
