import alitest
import time

def test_normal():
    print 'this is a print'
    assert 1 == 1


def test_fail_func():
    print 'this is a print'
    assert 1 == 2


@alitest.Marker.XFAIL(reason='should fail')
def test_xfail():
    assert 1 == 2


@alitest.Marker.XFAIL(reason='should success')
def test_xpass():
    assert 1 == 1



def dive_zero():
    return 1/0;


def test_deep_err():
    assert dive_zero()


def test_dive_zero():
    time.sleep(1)
    1/0
